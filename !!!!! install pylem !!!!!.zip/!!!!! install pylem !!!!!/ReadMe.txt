для установки pylem перенести эти папки в 
.venv/lib/python3.10/state-packages
